<footer class="text-center mt-5 py-4" style="background-color:#ffc0cb; color:white;">
    <div class="container">
        <p class="mb-2">&copy; <?= date("Y") ?> PinkBite Restaurant 🍓 All rights reserved.</p>
        <div class="d-flex justify-content-center gap-3">
            <a href="#" class="text-white fs-5"><i class="bi bi-instagram"></i></a>
            <a href="#" class="text-white fs-5"><i class="bi bi-facebook"></i></a>
            <a href="mailto:contact@pinkbite.com" class="text-white fs-5"><i class="bi bi-envelope-fill"></i></a>
        </div>
    </div>
</footer>
