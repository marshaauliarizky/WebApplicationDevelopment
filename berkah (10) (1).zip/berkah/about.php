<?php
$pageTitle = "About | PinkBite";
include 'header.php';
?>

<!-- About Section -->
<section class="py-5" style="background-color: #fff0f5;">
    <div class="container text-center">
    <h3 class="mb-4" style="color: #ff69b4; font-size: 36px;" data-aos="fade-up">୨ৎ About PinkBite ୨ৎ</h3>
    
    <p class="lead" style="max-width: 700px; margin: 0 auto; color: #555;" data-aos="fade-up" data-aos-delay="100">
        At <strong style="color: #ff69b4;">PinkBite</strong>, we believe food isn’t just a meal – it’s a hug in disguise. 💕
        Everything we serve is sprinkled with sweetness, wrapped in comfort, and colored in pink to make your day a little brighter.
    </p>

    <p class="mt-3" style="max-width: 700px; margin: 0 auto; color: #555;" data-aos="fade-up" data-aos-delay="200">
        Whether you're celebrating love, life, or just craving something cute and tasty, PinkBite is your sweet escape. From dreamy cakes to blushing lattes, every bite is meant to warm your heart and tickle your taste buds. 🍰✨
    </p>

<!-- image -->
<div class="my-5" data-aos="fade-up" data-aos-delay="200" style="text-align: center;">
    <img src="pink-restaurant.jpg" alt="About PinkBite"
        class="img-fluid rounded-4 shadow"
        style="max-height: 400px; object-fit: cover; border-radius: 16px;">
</div>

    <div class="mt-5" data-aos="fade-up" data-aos-delay="250">
        <h4 style="color: #ff69b4;">Why Pink?</h4>
    <p class="mt-2" style="color: #555; max-width: 700px; margin: 0 auto;">
        Why everything pink, you ask? 💗 Because our founder has always believed that pink is the color of warmth, joy, and pure love. It’s soft, comforting, and sweet – just like the desserts we serve.
        <br><br>
        From the pastel walls to the last swirl of cream, everything here is dipped in pink because... well, our heart beats in that color! 💞
    </p>
    </div>


    <p class="mt-4 fw-bold" style="color: #ff69b4;" data-aos="fade-up" data-aos-delay="300">
        PinkBite – Made with love, shared with smiles 💖
    </p>
    </div>
</section>

<!-- Optional: Add Cute Team or Gallery -->
<section class="py-5" style="background-color: #ffe4ec;">
    <div class="container text-center">
    <h4 style="color: #ff69b4;" data-aos="fade-up">Baked with Love, Just for You</h4>
    <p class="mt-3" style="color: #555;" data-aos="fade-up" data-aos-delay="100">
    Every sweet detail at PinkBite is lovingly crafted to brighten your day. Whether you're here for a cozy bite or a pink escape, we’re always baking something magical just for you. 🎂💫
    </p>
    </div>
</section>

<?php include 'footer.php'; ?>

<!-- AOS Init -->
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script>
    AOS.init();
</script>
